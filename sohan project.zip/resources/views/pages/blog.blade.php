<section class="">
    <div class="container px-6 py-10 mx-auto">
        <div class="text-center">
            <h1 class="text-2xl font-semibold text-gray-800 capitalize lg:text-3xl ">From the blog</h1>

            <p class="max-w-lg mx-auto mt-4 text-gray-500">
                Salami mustard spice tea fridge authentic Chinese food dish salt tasty liquor. Sweet savory foodtruck
                pie.
            </p>
        </div>

        <div class="grid grid-cols-1 gap-8 mt-8 md:mt-16 md:grid-cols-2 xl:grid-cols-3">
            <div>
                <div class="relative">
                    <img class="object-cover object-center w-full h-64 rounded-lg lg:h-80" src="https://images.unsplash.com/photo-1624996379697-f01d168b1a52?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80" alt="">

                    <div class="absolute bottom-0 flex p-3 bg-white ">
                        <img class="object-cover object-center w-10 h-10 rounded-full" src="https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80" alt="">

                        <div class="mx-4">
                            <h1 class="text-sm text-gray-700 ">Tom Hank</h1>
                            <p class="text-sm text-gray-500 ">Creative Director</p>
                        </div>
                    </div>
                </div>

                <h1 class="mt-6 text-xl font-semibold text-gray-800 ">
                    What do you want to know about halal food
                </h1>

                <hr class="w-32 my-6 text-amber-500">

                <p class="text-sm text-gray-500 ">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis fugit dolorum amet dolores
                    praesentium, alias nam? Tempore
                </p>

                <a href="#" class="inline-block mt-4 text-amber-500 underline hover:text-amber-400">Read more</a>
            </div>

            <div>
                <div class="relative">
                    <img class="object-cover object-center w-full h-64 rounded-lg lg:h-80" src="https://images.unsplash.com/photo-1590283603385-17ffb3a7f29f?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80" alt="">

                    <div class="absolute bottom-0 flex p-3 bg-white ">
                        <img class="object-cover object-center w-10 h-10 rounded-full"src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=880&q=80"alt="">

                        <div class="mx-4">
                            <h1 class="text-sm text-gray-700 ">arthur melo</h1>
                            <p class="text-sm text-gray-500 ">Creative Director</p>
                        </div>
                    </div>
                </div>

                <h1 class="mt-6 text-xl font-semibold text-gray-800 ">
                    All the food you want to know
                </h1>

                <hr class="w-32 my-6 text-amber-500">

                <p class="text-sm text-gray-500 ">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis fugit dolorum amet dolores
                    praesentium, alias nam? Tempore
                </p>

                <a href="#" class="inline-block mt-4 text-amber-500 underline hover:text-amber-400">Read more</a>
            </div>

            <div>
                <div class="relative">
                    <img class="object-cover object-center w-full h-64 rounded-lg lg:h-80" src="https://images.unsplash.com/photo-1597534458220-9fb4969f2df5?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1374&q=80" alt="">

                    <div class="absolute bottom-0 flex p-3 bg-white ">
                        <img class="object-cover object-center w-10 h-10 rounded-full" src="https://images.unsplash.com/photo-1531590878845-12627191e687?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=764&q=80" alt="">

                        <div class="mx-4">
                            <h1 class="text-sm text-gray-700 ">Amelia. Anderson</h1>
                            <p class="text-sm text-gray-500 ">Lead Developer</p>
                        </div>
                    </div>
                </div>

                <h1 class="mt-6 text-xl font-semibold text-gray-800 ">
                    Which services you get from us
                </h1>

                <hr class="w-32 my-6 text-amber-500">

                <p class="text-sm text-gray-500 ">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis fugit dolorum amet dolores
                    praesentium, alias nam? Tempore
                </p>

                <a href="#" class="inline-block mt-4 text-amber-500 underline hover:text-amber-400">Read more</a>
            </div>
        </div>
    </div>
</section>